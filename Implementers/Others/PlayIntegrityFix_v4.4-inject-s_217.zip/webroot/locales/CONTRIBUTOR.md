# Play Integrity Fix WebUI Translation Contributor List

## Arabic

- [ZG089](https://github.com/ZG089)

---

## Bahasa Indonesia

- [yourbestregard](https://github.com/yourbestregard)

---

## Chinese (Simplified)

- [KOWX712](https://github.com/KOWX712)

---

## Chinese (Traditional)

- [mattchengg](https://github.com/mattchengg)

---

## English

- [KOWX712](https://github.com/KOWX712)

---

## Turkish

- [DogancanYr](https://github.com/DogancanYr)

