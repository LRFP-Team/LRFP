#!/system/bin/sh

export TMP_PATH=/data/adb/neozygisk

rm -rf $TMP_PATH
